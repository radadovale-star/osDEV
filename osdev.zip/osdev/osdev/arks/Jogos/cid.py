import time
import os
import arks.LIBs.pudimlib as c
from arks.LIBs.pudimlib import escolher,limpar_tela,esperar



# ==============================
# SISTEMA
# ==============================

estado = {
    "moedas": 0,
    "reputacao": 0,
    "conhecimento": 0
}




def mostrar_status():
    print("\n--- SEU STATUS ---")
    print(f"Moedas: {estado['moedas']}")
    print(f"Reputação: {estado['reputacao']}")
    print(f"Conhecimento: {estado['conhecimento']}")


# ==============================
# CENA 1 - A CHEGADA
# ==============================

def cena1():
    limpar_tela()

    print(r"""
╔══════════════════════════════════════╗
║          CRÔNICAS MEDIEVAIS          ║
╚══════════════════════════════════════╝

              /\        /\
             /  \      /  \
            /____\    /____\
              ||        ||
         _____||________||_____
        |                       |
        |       VILA FRANCA     |
        |_______________________|

                 ANO 800
""")

    nome = "Junin"

    print(f"\n{nome}, você chega a uma pequena vila")
    print("do Império Carolíngio.")
    print("Você não possui terras nem dinheiro.")

    print("\nUm aldeão se aproxima.")

    print("\n[1] Conversar com o aldeão.")
    print("[2] Ir até o mercado.")
    print("[3] Procurar abrigo na igreja.")

    escolha = escolher(("1", "2", "3"))

    if escolha == "1":
        cena2()

    elif escolha == "2":
        cena3()

    else:
        cena4()


# ==============================
# CENA 2 - O ALDEÃO
# ==============================

def cena2():
    limpar_tela()

    print(r"""
╔══════════════════════════════════════╗
║             O ALDEÃO                 ║
╚══════════════════════════════════════╝

          O
         /|\
         / \
      ___| |___
     | PLANTAÇÃO |
     |___________|

""")

    print("O aldeão oferece trabalho em suas terras.")
    print("Em troca, você receberá comida e abrigo.")

    print("\n[1] Aceitar o trabalho.")
    print("[2] Pedir pagamento em moedas.")
    print("[3] Recusar.")

    escolha = escolher(("1", "2", "3"))

    if escolha == "1":
        estado["reputacao"] += 1
        cena5()

    elif escolha == "2":
        estado["moedas"] += 2
        cena5()

    else:
        cena6()


# ==============================
# CENA 3 - O MERCADO
# ==============================

def cena3():
    limpar_tela()

    print(r"""
╔══════════════════════════════════════╗
║              MERCADO                 ║
╚══════════════════════════════════════╝

       __________________
      |   MERCADO FRANCO  |
      |__________________|
          O       O
         /|\     /|\
         / \     / \

""")

    print("O mercado está movimentado.")
    print("Um comerciante oferece uma oportunidade.")

    print("\n[1] Trabalhar para o comerciante.")
    print("[2] Conversar com outros viajantes.")
    print("[3] Procurar um livro antigo.")

    escolha = escolher(("1", "2", "3"))

    if escolha == "1":
        estado["moedas"] += 2
        cena6()

    elif escolha == "2":
        estado["reputacao"] += 1
        cena9()

    else:
        estado["conhecimento"] += 1
        cena4()


# ==============================
# CENA 4 - O MOSTEIRO
# ==============================

def cena4():
    limpar_tela()

    print(r"""
╔══════════════════════════════════════╗
║              MOSTEIRO                ║
╚══════════════════════════════════════╝

       ___________________
      |                   |
      |   []   []   []    |
      |                   |
      |_______     _______|
              |   |
              |___|

""")

    print("Você encontra monges que oferecem abrigo.")
    print("Um deles pergunta se você deseja estudar.")

    print("\n[1] Aprender a ler e escrever.")
    print("[2] Ajudar nos trabalhos do mosteiro.")
    print("[3] Sair e procurar outra oportunidade.")

    escolha = escolher(("1", "2", "3"))

    if escolha == "1":
        estado["conhecimento"] += 2
        cena8()

    elif escolha == "2":
        estado["reputacao"] += 1
        cena7()

    else:
        cena5()


# ==============================
# CENA 5 - A ESTRADA
# ==============================

def cena5():
    limpar_tela()

    print(r"""
╔══════════════════════════════════════╗
║              A ESTRADA               ║
╚══════════════════════════════════════╝

          O
         /|\
         / \
    _____| |______
          ESTRADA
    __________________

""")

    print("Você encontra um grupo de viajantes.")
    print("Eles estão indo até uma cidade próxima.")

    print("\n[1] Viajar com o grupo.")
    print("[2] Continuar sozinho.")
    print("[3] Procurar uma patrulha franca.")

    escolha = escolher(("1", "2", "3"))

    if escolha == "1":
        estado["reputacao"] += 1
        cena9()

    elif escolha == "2":
        cena10()

    else:
        cena6()


# ==============================
# CENA 6 - OS SOLDADOS
# ==============================

def cena6():
    limpar_tela()

    print(r"""
╔══════════════════════════════════════╗
║            SOLDADOS FRANCOS          ║
╚══════════════════════════════════════╝

          O       O
         /|\     /|\
         / \     / \
       __|_______|__
      |   PATRULHA   |
      |______________|

""")

    print("Uma patrulha do Império Carolíngio")
    print("está recrutando pessoas para serviços.")

    print("\n[1] Oferecer seus serviços.")
    print("[2] Conversar com o comandante.")
    print("[3] Seguir viagem.")

    escolha = escolher(("1", "2", "3"))

    if escolha == "1":
        estado["reputacao"] += 2
        cena10()

    elif escolha == "2":
        estado["conhecimento"] += 1
        cena8()

    else:
        cena9()


# ==============================
# CENA 7 - A PROPRIEDADE
# ==============================

def cena7():
    limpar_tela()

    print(r"""
╔══════════════════════════════════════╗
║          A PROPRIEDADE RURAL         ║
╚══════════════════════════════════════╝

          __________
         |  MANOR   |
         |__________|
          |        |
          |________|

""")

    print("O senhor local percebe sua dedicação.")
    print("Ele oferece uma oportunidade.")

    print("\n[1] Trabalhar como administrador.")
    print("[2] Pedir terras para cultivar.")
    print("[3] Recusar a proposta.")

    escolha = escolher(("1", "2", "3"))

    if escolha == "1":
        estado["reputacao"] += 2
        cena11()

    elif escolha == "2":
        estado["moedas"] += 1
        estado["reputacao"] += 1
        cena12()

    else:
        cena9()


# ==============================
# CENA 8 - O ESCRIBA
# ==============================

def cena8():
    limpar_tela()

    print(r"""
╔══════════════════════════════════════╗
║             O ESCRIBA                ║
╚══════════════════════════════════════╝

          ___________
         |  LIVROS   |
         |___________|
          |  | |  |
          |__|_|__|

""")

    print("Um escriba trabalha copiando documentos.")
    print("Ele percebe seu interesse pelo conhecimento.")

    print("\n[1] Tornar-se seu aprendiz.")
    print("[2] Pedir que ensine administração.")
    print("[3] Procurar outro trabalho.")

    escolha = escolher(("1", "2", "3"))

    if escolha == "1":
        estado["conhecimento"] += 2
        cena12()

    elif escolha == "2":
        estado["conhecimento"] += 1
        estado["reputacao"] += 1
        cena11()

    else:
        cena9()


# ==============================
# CENA 9 - A CIDADE
# ==============================

def cena9():
    limpar_tela()

    print(r"""
╔══════════════════════════════════════╗
║              A CIDADE                ║
╚══════════════════════════════════════╝

       /\             /\
      /  \___________/  \
     |                   |
     |    CIDADE FRANCA  |
     |___________________|
        ||           ||

""")

    print("Você chega a uma cidade importante.")
    print("Há comerciantes, religiosos e funcionários.")

    print("\n[1] Procurar trabalho.")
    print("[2] Visitar a igreja.")
    print("[3] Procurar informações sobre Carlos Magno.")

    escolha = escolher(("1", "2", "3"))

    if escolha == "1":
        estado["moedas"] += 2
        cena12()

    elif escolha == "2":
        estado["reputacao"] += 1
        cena11()

    else:
        estado["conhecimento"] += 1
        cena13()


# ==============================
# CENA 10 - A MISSÃO
# ==============================

def cena10():
    limpar_tela()

    print(r"""
╔══════════════════════════════════════╗
║              A MISSÃO                ║
╚══════════════════════════════════════╝

             O
            /|\
            / \
       _____| |_____
           ESTRADA

""")

    print("Um funcionário imperial precisa")
    print("de alguém para entregar uma mensagem.")

    print("\n[1] Aceitar a missão.")
    print("[2] Pedir pagamento antecipado.")
    print("[3] Recusar.")

    escolha = escolher(("1", "2", "3"))

    if escolha == "1":
        estado["reputacao"] += 2
        cena13()

    elif escolha == "2":
        estado["moedas"] += 2
        cena13()

    else:
        cena12()


# ==============================
# CENA 11 - O NOBRE
# ==============================

def cena11():
    limpar_tela()

    print(r"""
╔══════════════════════════════════════╗
║             O NOBRE                  ║
╚══════════════════════════════════════╝

          ___________
         |  CASTELO  |
         |___________|
          |         |
          |_________|

""")

    print("Um nobre local deseja conhecê-lo.")
    print("Ele ouviu falar de seus serviços.")

    print("\n[1] Demonstrar lealdade.")
    print("[2] Conversar sobre administração.")
    print("[3] Pedir uma recompensa.")

    escolha = escolher(("1", "2", "3"))

    if escolha == "1":
        estado["reputacao"] += 2
        cena14()

    elif escolha == "2":
        estado["conhecimento"] += 2
        cena14()

    else:
        estado["moedas"] += 2
        cena12()


# ==============================
# CENA 12 - O INVERNO
# ==============================

def cena12():
    limpar_tela()

    print(r"""
╔══════════════════════════════════════╗
║              O INVERNO               ║
╚══════════════════════════════════════╝

             *
          *     *
       *    ___    *
           /___\
          |     |
          | CASA|
          |_____|

""")

    print("O inverno chega à região.")
    print("Os alimentos começam a ficar escassos.")

    print("\n[1] Ajudar os moradores.")
    print("[2] Usar suas moedas para comprar alimentos.")
    print("[3] Procurar abrigo na cidade.")

    escolha = escolher(("1", "2", "3"))

    if escolha == "1":
        estado["reputacao"] += 2
        cena13()

    elif escolha == "2":
        estado["moedas"] -= 1
        cena13()

    else:
        cena14()


# ==============================
# CENA 13 - O IMPÉRIO
# ==============================

def cena13():
    limpar_tela()

    print(r"""
╔══════════════════════════════════════╗
║            O IMPÉRIO                 ║
╚══════════════════════════════════════╝

       ___________________
      |                   |
      |   IMPÉRIO FRANCO  |
      |___________________|
           |       |
           |_______|

""")

    print("Você descobre que Carlos Magno")
    print("está reunindo representantes do império.")
    print("Uma reunião acontecerá em sua corte.")

    print("\n[1] Tentar participar da reunião.")
    print("[2] Procurar um nobre que o recomende.")
    print("[3] Voltar para sua vila.")

    escolha = escolher(("1", "2", "3"))

    if escolha == "1":
        estado["conhecimento"] += 1
        cena14()

    elif escolha == "2":
        estado["reputacao"] += 2
        cena14()

    else:
        cena15()


# ==============================
# CENA 14 - A CORTE
# ==============================

def cena14():
    limpar_tela()

    print(r"""
╔══════════════════════════════════════╗
║             A CORTE REAL             ║
╚══════════════════════════════════════╝

       ______________________
      |                      |
      |     GRANDE SALÃO     |
      |                      |
      |       ______         |
      |      |TRONO |        |
      |______|______|________|

""")

    print("Você chega à corte de Carlos Magno.")
    print("O imperador está recebendo seus convidados.")

    print("\n[1] Apresentar seus conhecimentos.")
    print("[2] Demonstrar sua lealdade.")
    print("[3] Pedir permissão para retornar à vila.")

    escolha = escolher(("1", "2", "3"))

    if escolha == "1":
        estado["conhecimento"] += 2
        cena15()

    elif escolha == "2":
        estado["reputacao"] += 2
        cena15()

    else:
        estado["moedas"] += 1
        cena15()


# ==============================
# CENA 15 - O DESTINO
# ==============================

def cena15():
    limpar_tela()

    print(r"""
╔══════════════════════════════════════╗
║              O DESTINO               ║
╚══════════════════════════════════════╝

              O
             /|\
             / \

       SUA HISTÓRIA CHEGA
          AO MOMENTO FINAL
""")

    print("Depois de sua longa jornada,")
    print("você precisa decidir seu futuro.")

    mostrar_status()

    print("\n[1] Permanecer na corte imperial.")
    print("[2] Construir uma vida na cidade.")
    print("[3] Voltar para sua vila.")

    escolha = escolher(("1", "2", "3"))

    if escolha == "1":
        if estado["reputacao"] >= 3 and estado["conhecimento"] >= 2:
            final_corte()
        else:
            final_rejeitado()

    elif escolha == "2":
        if estado["conhecimento"] >= 3:
            final_escriba()
        elif estado["moedas"] >= 3:
            final_comerciante()
        else:
            final_cidade()

    else:
        if estado["reputacao"] >= 3:
            final_lider()
        else:
            final_vila()


# ==============================
# FINAIS
# ==============================

def final_corte():
    limpar_tela()

    print(r"""
╔══════════════════════════════════════╗
║           FINAL: A CORTE             ║
╚══════════════════════════════════════╝

           _____________
          |  IMPÉRIO    |
          |_____________|
              |   |
              |___|

""")

    print("Sua reputação e conhecimento impressionaram")
    print("os representantes de Carlos Magno.")
    print("Você recebe um cargo na administração imperial.")
    print("\nSeu nome passa a ser conhecido na corte.")

    esperar()


def final_escriba():
    limpar_tela()

    print(r"""
╔══════════════════════════════════════╗
║          FINAL: O ESCRIBA            ║
╚══════════════════════════════════════╝

          ___________
         |  LIVROS   |
         |___________|

""")

    print("Você se tornou um escriba respeitado.")
    print("Seus conhecimentos ajudam a preservar")
    print("documentos e registros do império.")

    esperar()


def final_comerciante():
    limpar_tela()

    print(r"""
╔══════════════════════════════════════╗
║        FINAL: O COMERCIANTE          ║
╚══════════════════════════════════════╝

       __________________
      |    MERCADOR      |
      |__________________|

""")

    print("Suas economias permitiram iniciar")
    print("uma atividade comercial.")
    print("Você passa a viajar entre cidades.")

    esperar()


def final_lider():
    limpar_tela()

    print(r"""
╔══════════════════════════════════════╗
║           FINAL: O LÍDER             ║
╚══════════════════════════════════════╝

          O       O
         /|\     /|\
         / \     / \

""")

    print("Os moradores reconhecem sua dedicação.")
    print("Você retorna à vila e passa a representar")
    print("os interesses da comunidade.")

    esperar()


def final_vila():
    limpar_tela()

    print(r"""
╔══════════════════════════════════════╗
║           FINAL: A VILA              ║
╚══════════════════════════════════════╝

             /\
            /  \
           /____\
           | CASA|
           |_____|

""")

    print("Você retorna à vida simples.")
    print("Apesar das dificuldades, encontra")
    print("um lugar ao qual pode chamar de lar.")

    esperar()


def final_cidade():
    limpar_tela()

    print(r"""
╔══════════════════════════════════════╗
║          FINAL: A CIDADE             ║
╚══════════════════════════════════════╝

        /\          /\
       /  \________/  \
      |                |
      |     CIDADE     |
      |________________|

""")

    print("Você permanece na cidade.")
    print("Sua vida segue entre trabalhadores,")
    print("mercadores e outros habitantes.")

    esperar()


def final_rejeitado():
    limpar_tela()

    print(r"""
╔══════════════════════════════════════╗
║         FINAL: PORTAS FECHADAS       ║
╚══════════════════════════════════════╝

          ___________
         |  CASTELO  |
         |___________|
             || 
             ||

""")

    print("Você tentou conseguir um cargo na corte,")
    print("mas ainda não conquistou confiança")
    print("nem conhecimentos suficientes.")
    print("\nA corte fecha suas portas.")

    esperar()


# ==============================
# INICIAR JOGO
# ==============================

def iniciar():
    estado["moedas"] = 0
    estado["reputacao"] = 0
    estado["conhecimento"] = 0

    cena1()

