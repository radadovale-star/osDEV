import random
import arks.LIBs.pudimlib as com
import arks.LIBs.pudimlib as c
def ppt():
    c.limpar()
    while True:
        print("Escolha pedra, papel ou tesoura!")
        jg = input("osdev:~$ ").lower()

        pptes = ["pedra", "papel", "tesoura"]

        if jg not in pptes:
            print("Opção errada!")
            continue

        pc = random.choice(pptes)

        if (jg == "pedra" and pc == "tesoura") or (jg == "papel" and pc == "pedra") or (jg == "tesoura" and pc == "papel"):
            print("Você ganhou!")
            c.espera()
            c.limpar()
            c.ins()
            break
        elif jg == pc:
            print("Empate")
            c.espera()
            c.limpar()
        else:
            print("Você perdeu!")
            c.espera()
            c.limpar()
            
        
    


    

    

    