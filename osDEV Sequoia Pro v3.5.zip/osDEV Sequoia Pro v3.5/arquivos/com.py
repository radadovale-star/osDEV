# Sistema osDEV 
import json
import random
import os
import time
import tkinter as tk
from PIL import Image, ImageTk
from math import pi
arquivo = "usuario.json"
seta = "osdev:~$ "

def espera():
    print("\nAperte ENTER para continuar...")
    input()

def p(texto):
    print(texto)

def term(terminals):
    os.system(terminals)

def calc(num1, op, num2):
    while True:
        if op == "/":
            print(f"O Resultado foi.. {num1 / num2}")
            break
        elif op == "*":
            print(f"O Resultado foi.. {num1 * num2}")
            break
        elif op == "-":
            print(f"O Resultado foi.. {num1 - num2}")
            break
        elif op == "+":
            print(f"O Resultado foi.. {num1 + num2}")
            break
        else:
            print("Opção invalida.")

def tempo(segs):
    time.sleep(segs)

def ins():
    print(r"""     
================================
           osDEV
================================
""")

def limpar():
    term("cls" if os.name == "nt" else "clear")


def help():
    print(r"""
    echo ~> Mostra um texto(str) na tela
    clear ~> Limpa a tela
    exit ~> Sai do sistema :(
    help ~> Mostra os comandos que você pode usar
    info ~> Informaçoes do OS
    calc ~> Calculadora
    terminal ~> use o terminal do seu pc dentro de osDEV [Cuidado!]
    ppt ~> pedra,papel tesoura
    cr ~> Jogue As Correntes de Roma, via osDEV
    per ~> Calcule o perimetro
    area ~> Calcula a area de um objeto de 4 lados
    areac ~> Calcula a area de um circulo
    quiz ~> Quiz de Ciências!
    mens ~> Mostra a Mensagem incial
    """)

def info():
    ins()
    print(r"""
    Sistema Criado por: Rada
    Criado em 12/10/26
    Versão: osDEV Sequoia Pro (v3.5 PRO)

    i use osDEV btw
    """)

def mens():
    ins()

def area(valor1, valor2):
    conta = valor1 * 2
    conta2 = valor2 * 2
    final = conta + conta2
    return final

def perm(valor1, valor2):
    final = valor1 * valor2
    return final    

def area_circ(raio):
    from math import pi

    area = pi * raio ** 2

    return area








def iniciar():
    splash = tk.Tk()
    splash.overrideredirect(True)
    splash.configure(bg="black")

    imagem = Image.open("OSD.jpg").convert("RGBA")
    foto = ImageTk.PhotoImage(imagem)

    largura, altura = imagem.size

    tela_largura = splash.winfo_screenwidth()
    tela_altura = splash.winfo_screenheight()

    x = (tela_largura - largura) // 2
    y = (tela_altura - altura) // 2

    splash.geometry(f"{largura}x{altura}+{x}+{y}")

    label = tk.Label(splash, image=foto, bd=0)
    label.pack()

    splash.after(2500, splash.destroy)
    splash.mainloop()



















